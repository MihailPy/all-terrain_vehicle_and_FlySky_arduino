# FlySkyIBus

**This project has moved to https://gitlab.com/timwilkinson/FlySkyIBus**

An Arduino library to decode the serial FlySky i-bus data received by the FlySky FS-iA6B receiver.
